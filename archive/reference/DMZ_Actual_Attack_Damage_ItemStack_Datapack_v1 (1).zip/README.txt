DMZ LEGACY - ACTUAL ITEMSTACK ATTACK DAMAGE DATAPACK v1
Minecraft 1.20.1 / Forge

PURPOSE
-------
This is the standalone datapack for the ItemStack AttributeModifiers approach.
It does NOT use KubeJS and it does NOT change DMZ combo damage_multiplier JSON.

WHAT IT DOES
------------
* DMZ melee/tools listed in DMZ_ACTUAL_DAMAGE_TARGETS.json: actual displayed Attack Damage -> 25%.
* Simply Swords unique + runic weapons: actual displayed Attack Damage -> 10x installed default values.
* Simply More unique + Mimicry + runic weapons: actual displayed Attack Damage -> 10x installed default values.
* Preserves each weapon's normal attack-speed modifier by writing attack_damage + attack_speed together.
* Does NOT touch Tinkers weapons.
* Does NOT change DMZ laser/blaster projectile damage; those are not generic.attack_damage weapons.

HOW IT WORKS
------------
Minecraft 1.20.1 item modifiers can write AttributeModifiers NBT onto an ItemStack.
The pack checks player mainhand/offhand every 10 ticks. The first time an affected stack is held, it applies a fixed attack-damage and attack-speed modifier and marks that stack with DMZActualDamageV1:1b.
The change persists on the ItemStack after it leaves the hand.

INSTALL
-------
1. REMOVE/disable older DMZ Legacy balance datapacks that set x0.25/x10 combo damage, or you may double-scale combat.
2. REMOVE/disable the old KubeJS v3 actual-damage startup script if it is still installed.
3. Put this ZIP directly in <world>/datapacks/.
4. Run /reload (a server restart is also fine).
5. Hold an affected weapon for up to half a second. Its tooltip/AttributeModifiers should update.
6. To force the held-item pass immediately: /function dmz_actual_damage:apply_now

IMPORTANT LIMITATION
--------------------
This modifies ItemStacks, not the registered Java Item singleton. Items sitting untouched in chests will not change until a player holds them. Once held, the NBT modification persists.

BALANCE BASIS
-------------
Values were generated against the exact uploaded jars:
* DragonMineZ 2.1.3
* Simply Swords 1.56.0 for 1.20.1
* Simply More 1.1.3

Simply Swords / Simply More x10 values use the installed mod's DEFAULT weapon-attribute config values. If your server has customized those mods' own damage configs, the fixed targets in this datapack will not automatically follow those custom config values.
