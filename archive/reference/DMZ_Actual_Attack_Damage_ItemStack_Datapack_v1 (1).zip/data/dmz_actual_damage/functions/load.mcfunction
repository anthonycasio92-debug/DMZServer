schedule function dmz_actual_damage:loop 1t replace
