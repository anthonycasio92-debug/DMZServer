execute as @a run function dmz_actual_damage:apply_held
