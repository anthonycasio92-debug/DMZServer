execute as @a run function dmz_actual_damage:apply_held
schedule function dmz_actual_damage:loop 10t replace
